#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

FILE *dosya;

typedef struct
{
char ogrAd[30];
char ogrSoyad[30];
char *ogrBolum;
int toplamKredi;
int ogrNumarasi;
} ogrenciBilgileri;

typedef struct
{
char dersAdi[30];
int dersKredi;
int dersKodu;
} dersBilgileri;

ogrenciBilgileri ogrenciler [100000];    
int indexOgrenciler = 0;

//  Oluşturuluyor
ogrenciBilgileri  ogrenci_kayit() {
ogrenciBilgileri yeniOgrenci;
int limitKredi = 0;
getchar();
printf("...............OGRENCI KAYIT.............\n");
printf("Ogrenci adini giriniz: ");
gets(yeniOgrenci.ogrAd);
printf("Ogrenci soyadini giriniz: ");
gets(yeniOgrenci.ogrSoyad);
printf("Ogrencinin alabileceği max krediyi giriniz.");
scanf("%d", &limitKredi);
yeniOgrenci.toplamKredi = limitKredi;
yeniOgrenci.ogrBolum = "Bilgisayar Muhendisligi";
printf("\n");
srand(time(NULL));
    yeniOgrenci.ogrNumarasi=rand()%1000+100;

ogrenciler[indexOgrenciler] = yeniOgrenci;//öğrencileri diziye atıyoruz
indexOgrenciler++;
return yeniOgrenci;
}


int menu() {
int islem;
printf("---------------MENU-------------------------------------------------\n");
printf("1)OGRENCI KAYIT\n");
printf("2)OGRENCI KAYIT\n");
printf("3)OGRENCI LISTESI\n");
printf("4)DERS KAYIT\n");
printf("5)DERS SECIMI\n");
printf("6)DERS LISTESI\n");
printf("7)CIKIS YAP\n");
printf("------------------------------------------------------------------------\n");

printf("LUTFEN BIR ISLEM SECINIZ\n");
scanf("%d",&islem);

return islem;
}


int main(){

    int menuIslemi;
    ogrenciBilgileri yeniOgrenci;

        do
        {
            menuIslemi = menu();
                //ogrenci kayıt işlemi seçildiyse 
                if (menuIslemi==1)
                {
                    yeniOgrenci = ogrenci_kayit();
                    dosya = fopen("Ogrenciler.txt","w+");
                    
                    int i=0;
                    for(i=0; i<indexOgrenciler; i++) {
                    fprintf(dosya,"%d %s %s %c %d\n",ogrenciler[i].ogrNumarasi,ogrenciler[i].ogrAd,ogrenciler[i].ogrSoyad, ogrenciler[i].ogrBolum, ogrenciler[i].toplamKredi);
                    }
                    fclose(dosya);
                    
                }
                
        } while (menuIslemi !=7);
        
    
    return 0;
}